﻿Imports System.Data.OleDb
Public Class Form3

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As OleDbConnection = New OleDbConnection(" Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TEMP\Downloads\library mangement system2 VBB2.accdb")

        Dim con As OleDbCommand
        Dim cmd As OleDbDataAdapter
        con.open()
        cmd = con.CreateCommand()
        cmd.commandtype = CommandType.Text
        cmd.commandtext = "insert into table2 value('" + TextBox1.Text + "','" + ComboBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "')"
        cmd.ExecuteNonQuery()

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class