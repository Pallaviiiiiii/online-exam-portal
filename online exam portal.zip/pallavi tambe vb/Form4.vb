﻿Imports System.Data.OleDb
Public Class Form4

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As OleDbConnection = New OleDbConnection(" Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TEMP\Downloads\library mangement systeem VBB2.accdb")

        Dim cmd As OleDbDataAdapter
        con.open()
        OleDbCommand cmd = con.CreateCommand()
        cmd.commandtype = CommandType.Text
        cmd.commandtext = "select * from Customer_ID where Table2=('" + TextBox1.Text + "')"
        cmd.ExeucteNonQuery()
        DataTable dt = New DataTable()
        OleDbDataAdapter da = New OleDbDataAdapter(cmd)
        Da.fill(dt)
        dataGrideView1.Datasource = dt
        con.close()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class