﻿Imports System.Data.OleDb

Public Class Form5

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As OleDbConnection = New OleDbConnection(" Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TEMP\Downloads\library mangement system2 VBB2.accdb")


        Dim cmd As OleDbDataAdapter
        con.open()

        cmd = con.CreateCommand()
        cmd.commandtype = CommandType.Text
        cmd.commandtext = "insert into table3value('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "')"
        cmd.ExecuteNonQuery()

    End Sub
End Class